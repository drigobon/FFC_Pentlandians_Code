library(Amelia)
library(data.table)



## Read stage 1 csv, Features List
#Data_All <- read.csv('background.csv',stringsAsFactors = TRUE)
Data_2 <- read.csv('data_cleaned_stage2_Homeless.csv',stringsAsFactors = TRUE)
Features_2 <- read.csv('features_cleaned_stage2.csv')
Constr_Names <- read.csv('Constructed_Variable_Names.csv')$x

Data_C<-Data_2[,Constr_Names]

#neg <- Data_C[(Data_C < 0)]
#neg <- neg[!is.na(neg)]
#neg_val <- unique(neg[neg == floor(neg)])
neg_val <- c(-1:-11,-14,-15,-101)

# Remove negative codes
for (n in neg_val){
  Data_2[Data_2 == n] <- NA
}
Data_2<- Data_2[,-1]


## Impute with Means
Data_Mean <- Data_2
for (i in Features_2[which(Features_2$variable_type=='continuous'),]$variable){
  Data_Mean[,i][which(!is.finite(Data_Mean[,i]))] <- mean(Data_Mean[,i],na.rm = T)
}

write.csv(Data_Mean, file = 'data_mean_imputed.csv',row.names = F)